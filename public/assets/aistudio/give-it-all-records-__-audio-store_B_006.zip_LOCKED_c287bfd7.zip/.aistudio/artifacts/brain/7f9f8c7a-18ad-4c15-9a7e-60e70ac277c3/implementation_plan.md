# Implementation Plan - Build B_006: Licensing Accordion, Floating Mini-Player & Continuous Audition

This plan outlines the implementation for the upcoming **`B_006`** release of **Give It All Records**, staging three high-impact storefront enhancements prioritized during brainstorming.

---

## User Review Required

> [!IMPORTANT]
> - **Floating Mini-Player Dock Position**: The floating mini-player will dock at the bottom of the viewport with a slim terminal profile (38px–44px height), featuring phosphor green status indicators, quick play/pause, scrub indicator, and direct `[ ACQUIRE ]` button. It activates automatically whenever the primary oscilloscope monitor scrolls past the viewport.
> - **Preview Trigger Policy**: Per user instructions, these changes will be prepared and implemented into the codebase for the next build without triggering a premature preview generation until the explicit **"generate preview"** command is given.

---

## Proposed Changes

### 1. Collapsible Perpetual Licensing Accordion
#### `src/App.tsx`
- Replace the permanently expanded 4-pillar licensing section with a collapsible accordion component.
- **Default State**: Collapsed, displaying a tactile hardware-inspired trigger bar:
  - `[+] VIEW PERPETUAL LICENSING & $2,000 REVENUE CEILING TERMS`
  - Badges: `100% DIRECT RIGHTS`, `NEVER CONTENT-ID FLAGGED`, `PERPETUAL WORLDWIDE SYNC`.
- **Expanded State**: Smoothly unveils the full 4-pillar specification cards (`24-Bit WAV`, `Perpetual Sync`, `$2,000 / 100K Stream Ceiling`, `Vocal Lease & Stems`) and legal compliance notes.
- **Header Nav Integration**: Clicking `02. PERPETUAL LICENSING` in the top header auto-expands the accordion and smoothly scrolls down to the section.

---

### 2. Persistent Floating Mini-Player Dock
#### `src/App.tsx` & `src/index.css`
- Add an `IntersectionObserver` or scroll-position listener targeting the `#audio-monitor` section.
- When the active track is playing or loaded and the main oscilloscope monitor is scrolled out of viewport:
  - A slim terminal dock slides into the bottom viewport.
  - Controls: Play / Stop / Pause toggle, current track title + artist, format badge (`24-BIT WAV`), elapsed/total time, mini progress scrub bar, and instant `[ + ACQUIRE $49 ]` / `[ IN CRATE ]` button.
  - Fully responsive and styled in dark graphite (`#09090b`), emerald phosphor borders (`#10b981`), and monospace typography.

---

### 3. Continuous Audition Mode ("Auto-Advance")
#### `src/App.tsx`
- Add an `autoAdvance` boolean state (default: `true` or user-toggleable via a sleek `[AUTO-ADVANCE: ON/OFF]` switch in the playback monitor controls).
- Attach an `onEnded` event listener to the HTMLAudioElement:
  - When the current track completes and `autoAdvance` is enabled, the player automatically selects the next track in the active filter list and begins playback seamlessly.
  - If the last track finishes, it loops gracefully back to track 01.

---

### 4. Build Stamp & Release Version Advancement
#### `src/App.tsx`, `package.json`, `index.html`
- Advance all version stamps to `REV: B_006`.
- Update project header stamp: `GIVE IT ALL RECORDS // AUDIO ENGINE REV: B_006`.
- Update zip archive download stamp and metadata to `give-it-all-records-__-audio-store_B_006.zip`.

---

## Verification Plan

### Automated Build & Syntax Verification
- Run `npm run lint` and `compile_applet` to verify TypeScript types, React lifecycle dependencies, and audio event listeners compile without warnings or errors.

### Manual Verification
1. **Licensing Accordion**:
   - Check that the storefront loads with the licensing accordion collapsed by default.
   - Click the toggle button to verify all 4 pillar cards and legal details expand cleanly without layout shifting.
   - Click `02. PERPETUAL LICENSING` in the top navigation bar to confirm it auto-expands and smoothly scrolls into view.
2. **Floating Mini-Player**:
   - Play any track in the top monitor and scroll down through the catalogue.
   - Verify the mini-player slides into the bottom viewport as soon as the main monitor leaves the screen.
   - Test Play, Stop, and `[ ACQUIRE ]` interactions directly from the floating mini-player.
3. **Continuous Audition**:
   - Enable `[AUTO-ADVANCE: ON]` and scrub near the end of a track.
   - Verify playback transitions smoothly into the next track.
   - Toggle `[AUTO-ADVANCE: OFF]` and verify playback cleanly halts at track conclusion.
